//-----------------------------------------------------------------------------
// Descrizione dei dati
//-----------------------------------------------------------------------------
I dati rappresentano il funzionamento di un robot che svolge cicli di lavoro.  Sono riportati i raw data di ciascun ciclo.

Le prime sei colonne riportano i valori di corrente, un valore per ciascuno dei sei bracci. Le successive sei colonne riportano i valori di posizione, un valore per ciascun braccio.
La colonna M contiene il tipo del di log
La colonna N contiene il timestamp
La colonna O contiene l'identificativo del ciclo di lavorazione

I dataset sono organizzati in cinque gruppi: uno per i file del robot generati in condizioni nominali, gli altri tre per condizioni specifiche, un quarto di test.

└── [4.0K]  robot
    ├── [4.0K]  rawData
    │   ├── [5.0M]  dryBearing.zip
    │   ├── [ 11M]  nominal.zip
    │   ├── [5.0M]  noPayload.zip
    │   ├── [5.1M]  oilLeakage.zip
    │   └── [7.6M]  test.zip
    └── [1.4K]  readme.txt



//-----------------------------------------------------------------------------
// Riservatezza
//-----------------------------------------------------------------------------
I dati vengono forniti per un uso finalizzato alle sole attivita' del laboratorio "Lab Master Mains XI Machine Learning". Ogni altro impiego dei dati non e' consentito.
